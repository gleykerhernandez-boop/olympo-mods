# Dependencias y limites

- Minecraft 1.21.1, formato de resource pack 34. Sin mods obligatorios: es vanilla-compatible (NeoForge y Arclight lo cargan igual porque es solo cliente).
- Las texturas de `block/olympo/*` NO se ven en el juego por si solas: necesitan un mod/datapack que registre bloques con esas texturas. Un resource pack no crea bloques funcionales.
- Items con custom_model_data (stick, paper): se obtienen con `/give` o desde un plugin/mod que fije el componente.
- Reemplazos vanilla (cuarzo, blackstone pulida, prismarine, oro, lapis, amatista, obsidiana llorosa, sea lantern, portal, musgo, hojas de cerezo, arena de almas, diorita/granito/andesita pulidos) cambian TODOS los usos de esos bloques para quien use el pack, tambien fuera del mapa.
- El menu principal, pantallas del lanzador/launcher y la UI de vanilla NO se rediseñan aqui (solo pack.png). Hacerlo requiere mods de cliente.
- Modelos 3D personalizados (armas en 3D, estatuas) requieren Blockbench y/o mod de soporte; no incluidos.
- Si usas shaders/Optifine/Sodium: las texturas animadas (sea_lantern, nether_portal) funcionan con Sodium; sin problemas conocidos (no probado en juego).
