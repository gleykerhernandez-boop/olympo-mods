# Lista de texturas, bloques e items

## 1) Texturas que REEMPLAZAN bloques vanilla (se ven ya en el mapa)

- `assets/minecraft/textures/block/quartz_block_side.png` - Marmol divino blanco con vetas doradas (bloque de cuarzo)
- `assets/minecraft/textures/block/quartz_block_top.png` - Marmol divino blanco - cara superior
- `assets/minecraft/textures/block/quartz_block_bottom.png` - Marmol divino blanco liso (cuarzo liso / smooth_quartz)
- `assets/minecraft/textures/block/quartz_bricks.png` - Ladrillos de marmol divino
- `assets/minecraft/textures/block/quartz_pillar.png` - Columna de marmol con acanaladuras y filete dorado
- `assets/minecraft/textures/block/quartz_pillar_top.png` - Columna - tapa
- `assets/minecraft/textures/block/chiseled_quartz_block.png` - Marmol cincelado con emblema dorado
- `assets/minecraft/textures/block/chiseled_quartz_block_top.png` - Marmol cincelado - tapa
- `assets/minecraft/textures/block/polished_diorite.png` - Marmol celestial azul-blanco
- `assets/minecraft/textures/block/polished_granite.png` - Marmol rosado (Afrodita)
- `assets/minecraft/textures/block/polished_andesite.png` - Piedra antigua musgosa
- `assets/minecraft/textures/block/polished_blackstone.png` - Marmol oscuro del Inframundo con vetas violeta
- `assets/minecraft/textures/block/polished_blackstone_bricks.png` - Ladrillos de marmol oscuro
- `assets/minecraft/textures/block/chiseled_polished_blackstone.png` - Marmol oscuro cincelado con rune violeta
- `assets/minecraft/textures/block/gilded_blackstone.png` - Marmol oscuro con oro del Hades
- `assets/minecraft/textures/block/prismarine.png` - Piedra submarina de Poseidon
- `assets/minecraft/textures/block/dark_prismarine.png` - Piedra submarina de Poseidon
- `assets/minecraft/textures/block/prismarine_bricks.png` - Ladrillos submarinos
- `assets/minecraft/textures/block/gold_block.png` - Oro divino pulido
- `assets/minecraft/textures/block/lapis_block.png` - Lapislazuli del cielo con motas doradas
- `assets/minecraft/textures/block/amethyst_block.png` - Cristal magico violeta con facetas
- `assets/minecraft/textures/block/crying_obsidian.png` - Cristal divino/energia (obsidiana llorosa)
- `assets/minecraft/textures/block/sea_lantern.png` - Luz celestial animada (4 fotogramas)
- `assets/minecraft/textures/block/nether_portal.png` - Portal divino animado (32 fotogramas): vortice violeta-dorado
- `assets/minecraft/textures/block/moss_block.png` - Musgo profundo (Bosque Prohibido / Jardin)
- `assets/minecraft/textures/block/cherry_leaves.png` - Hojas de cerezo rosa vivo (Afrodita / Cupido)
- `assets/minecraft/textures/block/soul_sand.png` - Arena de almas del Estigia con motas espectrales

## 2) Items con custom_model_data (armas, llaves, reliquias)

- `assets/minecraft/textures/item/olympo/espada_zeus.png` - Espada de Zeus (amarillo electrico)
- `assets/minecraft/textures/item/olympo/espada_hades.png` - Espada del Inframundo
- `assets/minecraft/textures/item/olympo/daga_hades.png` - Daga oscura
- `assets/minecraft/textures/item/olympo/tridente_poseidon.png` - Tridente de Poseidon
- `assets/minecraft/textures/item/olympo/arco_cupido.png` - Arco de Cupido (corazon)
- `assets/minecraft/textures/item/olympo/baston_olimpo.png` - Baston del Olimpo
- `assets/minecraft/textures/item/olympo/llave_olimpo.png` - Llave de oro del Olimpo
- `assets/minecraft/textures/item/olympo/llave_inframundo.png` - Llave del Inframundo
- `assets/minecraft/textures/item/olympo/llave_cupido.png` - Llave de Cupido
- `assets/minecraft/textures/item/olympo/reliquia_rayo.png` - Reliquia del Rayo
- `assets/minecraft/textures/item/olympo/reliquia_ola.png` - Reliquia de la Ola
- `assets/minecraft/textures/item/olympo/reliquia_corazon.png` - Reliquia del Corazon
- `assets/minecraft/textures/item/olympo/reliquia_sombra.png` - Reliquia de la Sombra
- `assets/minecraft/textures/item/olympo/moneda_olimpo.png` - Moneda del casino / mercado
- `assets/minecraft/textures/item/olympo/estrella_zodiaco.png` - Fragmento de constelacion
- `assets/minecraft/models/item/stick.json` - Modelo base de stick con overrides 1001..1006
- `assets/minecraft/models/item/paper.json` - Modelo base de paper con overrides 2001..2009

## 3) Texturas para bloques NUEVOS (necesitan un mod que registre el bloque)

- `assets/minecraft/textures/block/olympo/marmol_divino_dorado.png` - Textura lista para el bloque "marmol_divino_dorado" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/marmol_celestial.png` - Textura lista para el bloque "marmol_celestial" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/marmol_rosado.png` - Textura lista para el bloque "marmol_rosado" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/marmol_oscuro.png` - Textura lista para el bloque "marmol_oscuro" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/piedra_inframundo.png` - Textura lista para el bloque "piedra_inframundo" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/piedra_volcanica.png` - Textura lista para el bloque "piedra_volcanica" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/piedra_submarina.png` - Textura lista para el bloque "piedra_submarina" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/piedra_antigua.png` - Textura lista para el bloque "piedra_antigua" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/cristal_magico.png` - Textura lista para el bloque "cristal_magico" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/cristal_divino.png` - Textura lista para el bloque "cristal_divino" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/energia_zeus.png` - Textura lista para el bloque "energia_zeus" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/energia_hades.png` - Textura lista para el bloque "energia_hades" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/zeus_nube.png` - Textura lista para el bloque "zeus_nube" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/poseidon_coral.png` - Textura lista para el bloque "poseidon_coral" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/afrodita_petalo.png` - Textura lista para el bloque "afrodita_petalo" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/hades_ceniza.png` - Textura lista para el bloque "hades_ceniza" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/cupido_corazon.png` - Textura lista para el bloque "cupido_corazon" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/elisathea_luz.png` - Textura lista para el bloque "elisathea_luz" - no se muestra hasta que un mod registre un bloque con esa textura
- `assets/minecraft/textures/block/olympo/arbol_gigante_corteza.png` - Textura lista para el bloque "arbol_gigante_corteza" - no se muestra hasta que un mod registre un bloque con esa textura

## custom_model_data

Para dar el item en el juego:

```
/give @s minecraft:stick[minecraft:custom_model_data=1001] 1   # tridente_poseidon
/give @s minecraft:stick[minecraft:custom_model_data=1002] 1   # espada_zeus
/give @s minecraft:stick[minecraft:custom_model_data=1003] 1   # espada_hades
/give @s minecraft:stick[minecraft:custom_model_data=1004] 1   # daga_hades
/give @s minecraft:stick[minecraft:custom_model_data=1005] 1   # arco_cupido
/give @s minecraft:stick[minecraft:custom_model_data=1006] 1   # baston_olimpo
/give @s minecraft:paper[minecraft:custom_model_data=2001] 1   # llave_olimpo
/give @s minecraft:paper[minecraft:custom_model_data=2002] 1   # llave_inframundo
/give @s minecraft:paper[minecraft:custom_model_data=2003] 1   # llave_cupido
/give @s minecraft:paper[minecraft:custom_model_data=2004] 1   # reliquia_rayo
/give @s minecraft:paper[minecraft:custom_model_data=2005] 1   # reliquia_ola
/give @s minecraft:paper[minecraft:custom_model_data=2006] 1   # reliquia_corazon
/give @s minecraft:paper[minecraft:custom_model_data=2007] 1   # reliquia_sombra
/give @s minecraft:paper[minecraft:custom_model_data=2008] 1   # moneda_olimpo
/give @s minecraft:paper[minecraft:custom_model_data=2009] 1   # estrella_zodiaco
```
