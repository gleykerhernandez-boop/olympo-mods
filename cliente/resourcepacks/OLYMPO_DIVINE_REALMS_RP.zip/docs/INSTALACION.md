# Instalacion y distribucion

## Jugador (manual)
1. Copia `OLYMPO_DIVINE_REALMS_RP.zip` a `.minecraft/resourcepacks/` (o la carpeta del launcher OLYMPO: `cliente/resourcepacks/` se instala automaticamente).
2. Opciones > Paquetes de recursos > activar.

## Servidor (Arclight / NeoForge)
1. Sube el ZIP a un hosting con enlace directo (HTTPS, descarga directa). **No hay URL en este paquete: debes poner la tuya.**
2. Calcula SHA-1 (en el servidor): `sha1sum OLYMPO_DIVINE_REALMS_RP.zip`  (el SHA-1 del zip esta en el archivo `SHA1_resourcepack.txt` que acompana al paquete).
3. En `server.properties`:
```
resource-pack=<TU_URL_DIRECTA>/OLYMPO_DIVINE_REALMS_RP.zip
resource-pack-sha1=<SHA1 de SHA1_resourcepack.txt>
require-resource-pack=false
```
4. Cada vez que cambies el zip, recalcula el SHA-1 y cambia ligeramente la URL (ej. `?v=2`) para forzar la descarga.
